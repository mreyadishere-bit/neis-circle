NEIS Circle share image package
Main: assets/share/home-main.webp (three boys, no red cheeks)
Home app: preserve original image, unchanged
Sections: articles, circles, connections, discover, feed, gallery, messages, opportunities, saved, study, analytics, timetable, notifications, settings, games
All images: 1200x630 WebP
